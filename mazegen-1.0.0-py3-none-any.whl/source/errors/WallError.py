class WallError(Exception):
    pass
